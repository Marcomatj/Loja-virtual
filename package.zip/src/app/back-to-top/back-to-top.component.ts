import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'l-virtual-back-to-top',
  templateUrl: './back-to-top.component.html',
  styleUrls: ['./back-to-top.component.css']
})
export class BackToTopComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
