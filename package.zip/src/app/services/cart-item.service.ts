import { CartItemModel } from 'src/app/models/cart-item.model';
import { Injectable } from "@angular/core";

@Injectable()
export class CartItemService {

  items: CartItemModel[] = []

  constructor(){  }

  add(item: CartItemModel){

    this.items.push(item)
    console.log(`add: O item ${item.name} foi adicionado ao carrinho`)

  }
}
