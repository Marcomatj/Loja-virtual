import { environment } from 'src/environments/environment';

export const APP_API = environment.api