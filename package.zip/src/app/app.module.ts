import { ROUTES } from './app.routes';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { BackToTopComponent } from './back-to-top/back-to-top.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { ProductListComponent } from './product/product-list/product-list.component';
import { ProductDetailComponent } from './product/product-detail/product-detail.component';
import { RouterModule } from '@angular/router';

import { HttpClientModule } from '@angular/common/http'
import { ProductService } from './services/product.service';
import { CartItemService } from './services/cart-item.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    BackToTopComponent,
    FooterComponent,
    HomeComponent,
    AboutComponent,
    NotFoundComponent,
    ProductListComponent,
    ProductDetailComponent
  ],
  imports: [
    BrowserModule,

    HttpClientModule,

    RouterModule.forRoot(ROUTES, {})
  ],
  providers: [
    ProductService,
    CartItemService
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }
